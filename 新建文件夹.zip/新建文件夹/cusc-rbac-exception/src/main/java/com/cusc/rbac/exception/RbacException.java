package com.cusc.rbac.exception;

import java.util.Map;

import com.cusc.rbac.exception.constant.ExceptionLevel;

/**
 * 定义统一异常
 * @author 024-win7-024-DT24
 *
 */
public class RbacException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8153163675255360598L;
	
    /**
     * 异常级别
     */
    private ExceptionLevel level = ExceptionLevel.SLIGHT;

    /**
     * 异常错误信息
     */
    private String errorMessage = "";

    /**
     * 业务模块
     */
    private String businessModule = "未知";

    /**
     * 异常上下文，可以设置一些关键业务参数
     */
    private Map<String, Object> context;

    /**
     * 自定义errorCode,可根据这个errorCode做异常的筛选、特殊处理
     */
    private String errorCode = "0"; 
    
    
    /**
     * 构造统一异常
     * @param level          异常级别
     * @see com.alibaba.nazca.commonservice.exception.constant.ExceptionLevel
     * @param errorMessage   异常errorMessage
     * @param errorCode      异常errorCode
     * @param businessModule 异常业务模块
     * @param context        异常上下文，可以设置关键业务参数
     * @param cause          the throwable which caused this UnifiedException
     */
    public RbacException(ExceptionLevel level, String errorMessage, String errorCode, String businessModule,
                            Map<String, Object> context, Throwable cause) {
        super(cause);
        this.level = level;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.businessModule = businessModule;
        this.context = context;
    }
    

    /**
     * 是否已处理过
     */
    private boolean isHandled = false;

	public ExceptionLevel getLevel() {
		return level;
	}

	public void setLevel(ExceptionLevel level) {
		this.level = level;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getBusinessModule() {
		return businessModule;
	}

	public void setBusinessModule(String businessModule) {
		this.businessModule = businessModule;
	}

	public Map<String, Object> getContext() {
		return context;
	}

	public void setContext(Map<String, Object> context) {
		this.context = context;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public boolean isHandled() {
		return isHandled;
	}

	public void setHandled(boolean isHandled) {
		this.isHandled = isHandled;
	}

}
