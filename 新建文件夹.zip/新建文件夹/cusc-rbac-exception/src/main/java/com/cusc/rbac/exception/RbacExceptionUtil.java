package com.cusc.rbac.exception;

import java.util.Map;

import com.cusc.rbac.exception.constant.ExceptionLevel;

/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class RbacExceptionUtil {
	
	
	/**
     * 抛出轻微等级异常
     *
     * @param errorDefinition 必填，异常错误message、错误code
     * @param businessModule  必填，异常所属模块
     * @param context         选填，异常上下文，可以设置业务关键字
     * @param cause           选填
     * @throws RbacException
     */
    public static void throwSlightException(String message,String code, String businessModule,
                                            Map<String, Object> context, Throwable cause) throws RbacException {
        throw new RbacException(ExceptionLevel.SLIGHT, message,code, businessModule, context, cause);
    }

    /**
     * 抛出一般等级异常
     *
     * @param errorDefinition 必填，异常错误message、错误code
     * @param businessModule  必填，异常所属模块
     * @param context         选填，异常上下文，可以设置业务关键字
     * @param cause           选填
     * @throws RbacException
     */
    public static void throwCommonException(String message,String code, String businessModule,
                                            Map<String, Object> context, Throwable cause) throws RbacException {
        throw new RbacException(ExceptionLevel.COMMON, message,code, businessModule, context, cause);
    }

    /**
     * 抛出严重等级异常
     *
     * @param errorDefinition 必填，异常错误message、错误code
     * @param businessModule  必填，异常所属模块
     * @param context         选填，异常上下文，可以设置业务关键字
     * @param cause           选填
     * @throws RbacException
     */
    public static void throwSeriousException(String message,String code, String businessModule,
                                             Map<String, Object> context, Throwable cause) throws RbacException {
        throw new RbacException(ExceptionLevel.SERIOUS, message,code, businessModule, context, cause);
    }

}
