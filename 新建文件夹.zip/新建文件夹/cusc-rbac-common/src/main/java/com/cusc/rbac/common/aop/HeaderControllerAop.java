package com.cusc.rbac.common.aop;

import java.io.PrintWriter;
import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSONObject;
import com.cusc.rbac.common.annotation.ValidateHeader;
import com.cusc.rbac.common.validateRule.ValidateHeaderRule;


 
@Aspect
@Component
@Order(1)
public class HeaderControllerAop {
	
	 private static final String PASS_CODE = "200" ;
	  
	 @Value("${spring.application.name}")  
	 private String systemCode;  
	 @Autowired
	 private ValidateHeaderRule validateHeaderRule;
	 
	 @Pointcut("execution(* com.cusc.rbac.api.services..*.*(..))")
	 public void controllerMethodPointcut(){}; 
	 
	 @Before("controllerMethodPointcut()")
	 public Object Interceptor(JoinPoint point) throws Exception{
		 Object result = true;
		 MethodSignature signature = (MethodSignature) point.getSignature();  
	     Method method = signature.getMethod(); //获取被拦截的方法 
	     ValidateHeader validateHeader = method.getAnnotation(ValidateHeader.class);
	     RequestAttributes ra = RequestContextHolder.getRequestAttributes();
         ServletRequestAttributes sra = (ServletRequestAttributes) ra;
         HttpServletRequest request = sra.getRequest();
         HttpServletResponse response = sra.getResponse();
	     if(validateHeader != null){
	    	 return	 responseData(request,response);
	     }
		 return result;
	 }
	 
	 public Boolean responseData(HttpServletRequest request,HttpServletResponse response) throws Exception{
		 Boolean result = true ;
		 String SystemCode =  request.getHeader("SystemCode");
	     String UserToken  =  request.getHeader("UserToken"); 
	     String UserId     =  request.getParameter("UserId")!=null?request.getParameter("UserId"):request.getHeader("UserId");
	     String CurTime    =  request.getHeader("CurTime")!=null?request.getHeader("CurTime"):request.getParameter("CurTime");
	     
	     JSONObject json = validateHeaderRule.rule(SystemCode,CurTime,UserToken,UserId);
	     if(!json.get("code").equals(PASS_CODE)){
	    	 response.reset();
	    	 response.setCharacterEncoding("UTF-8");  
	    	 response.setContentType("application/json; charset=utf-8");
	    	 PrintWriter out = response.getWriter();
			    out.append(json.toString());
			    out.flush();
			    out.close();
			    result = false ;
	     }
	     return result;
	 };

}
