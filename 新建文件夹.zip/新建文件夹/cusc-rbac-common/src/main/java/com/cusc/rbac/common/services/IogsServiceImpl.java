package com.cusc.rbac.common.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.cusc.rbac.common.dao.ILogsDao;
import com.cusc.rbac.common.vo.LogsVO;

@Service
public class IogsServiceImpl implements IIogsService{
	
	@Autowired
	private ILogsDao logsDao;

	@Override
	@Async
	public void addLogs(LogsVO logsVO) {
		logsDao.addLogs(logsVO);
	}

}
