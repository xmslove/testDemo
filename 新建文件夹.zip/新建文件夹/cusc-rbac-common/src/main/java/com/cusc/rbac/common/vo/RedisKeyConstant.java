package com.cusc.rbac.common.vo;

public class RedisKeyConstant {
	
	/**
	 * 主键策略
	 * 权限的KEY模式
	 */
	public static final String PERMISSION_KEY = "PERMISSION" ; 
	
	/**
	 * 主键策略
	 * 用户角色的KEY模式
	 */
	public static final String USERROLE_KEY = "ROLE" ; 
	
	/**
	 * 主键策略
	 * 用户组的KEY模式
	 */
	public static final String USERGROUP_KEY = "GROUP" ;
	
	

}
