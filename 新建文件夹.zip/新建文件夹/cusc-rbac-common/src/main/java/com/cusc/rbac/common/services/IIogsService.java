package com.cusc.rbac.common.services;

import com.cusc.rbac.common.vo.LogsVO;

public interface IIogsService {
	
	/**
	 * 添加日志
	 * @param logsVO
	 */
	public void addLogs(LogsVO logsVO);

}
