package com.cusc.rbac.common.vo;

public enum  ResponseCode {
	
	ERROR1001("RBAC1001","请检查系统code"),
	ERROR1002("RBAC1002","请检查时间戳"),
	ERROR1003("RBAC1003","请检查用户token"),
	ERROR1004("RBAC1004","请检查用户ID"),
	ERROR1005("RBAC1005","时间戳格式错误"),
	ERROR1006("RBAC1006","token错误");
	
	private String code;
	private String msg;
	
	private ResponseCode(String code,String msg){
		this.code = code;
		this.msg = msg;
	}
	
	public static String getErrorCode(String code){
		ResponseCode rc = null;
		for (ResponseCode ErrorCode : values()) {
			if(code==ErrorCode.code){
				rc=ErrorCode;
			}
		}
		return rc.msg;
	}

}
