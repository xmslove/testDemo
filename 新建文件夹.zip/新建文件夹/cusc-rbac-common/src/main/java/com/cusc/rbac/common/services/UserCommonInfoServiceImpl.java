package com.cusc.rbac.common.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cusc.rbac.common.dao.IUserCommonInfoDao;
import com.cusc.rbac.common.util.CheckSumBuilderUtil;

@Service
public class UserCommonInfoServiceImpl implements IUserCommonInfoService{
	
	@Autowired
	private IUserCommonInfoDao userCommonInfoDao;

	@Override
	public String getUserToken(String systemCode,Long UserId,String curTime) {
		String userToken = null ; 
		String userPwd = userCommonInfoDao.getUserPwd(systemCode,UserId);
	    userToken =  CheckSumBuilderUtil.getToken(UserId,userPwd,curTime);
		return userToken;
	}

}
