package com.cusc.rbac.common.vo;

import java.io.Serializable;
/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class PrivilegeVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5045322275234703528L;
	
	private String operationCode;
	
	private String operationDesc;
	
	private String operationType;
	
	private String systemCode;
	
	private String parentCode;

	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	public String getOperationDesc() {
		return operationDesc;
	}

	public void setOperationDesc(String operationDesc) {
		this.operationDesc = operationDesc;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	public String getParentCode() {
		return parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

}
