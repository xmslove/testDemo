package com.cusc.rbac.common.vo;

import java.io.Serializable;
import java.util.List;
/**
 * 
 * @author 024-win7-024-DT24
 * @param <T>
 *
 */
public class ResponseVO<T> implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 655776372369857605L;

	private String code = "200";
	
	private String msg = "请求成功";
	
    private List<T> data;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}
}
