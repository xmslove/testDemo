package com.cusc.rbac.common.vo;

import java.io.Serializable;
/**
 * 用户信息
 * @author 024-win7-024-DT24
 *
 */
public class UserVO  extends BaseVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 221635768287623670L;
	
	private Long userId;
	
	private String userName;
	
	private String userPassword;
	
	private String userMobileNo;
	
	private String email;
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserMobileNo() {
		return userMobileNo;
	}

	public void setUserMobileNo(String userMobileNo) {
		this.userMobileNo = userMobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
