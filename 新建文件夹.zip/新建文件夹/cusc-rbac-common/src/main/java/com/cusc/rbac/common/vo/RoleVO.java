package com.cusc.rbac.common.vo;

import java.io.Serializable;
/**
 * 用户角色
 * @author 024-win7-024-DT24
 *
 */
public class RoleVO extends BaseVO  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3278739152288467845L;
	
    	
    private Long roleId;
    
    private String roleName;
    
    private String roleDesc;

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
}
