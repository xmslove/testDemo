package com.cusc.rbac.common.redis.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedisPool;
/**
 * redis手动配置实现集群
 * 只需要添加JedisShardInfo的手动配置即可
 * @author 024-win7-024-DT24
 *
 */
@Configuration
public class RedisConfiguration {
	
	    @Bean(name= "sardedJedisPool")  
	    @Autowired  
	    public ShardedJedisPool shardedJedisPool(
	    		@Qualifier("jedisPoolConfig") JedisPoolConfig jedisPoolConfig,  
	    		@Qualifier("jedisShardInfo") JedisShardInfo jedisShardInfoConfig
	             ) { 
	    	List<JedisShardInfo> shards = new ArrayList<JedisShardInfo>();
	    	shards.add(jedisShardInfoConfig);
	    	ShardedJedisPool sp = new ShardedJedisPool(jedisPoolConfig, shards);
	        return sp;  
	    }  
	      
	    @Bean(name= "jedisPoolConfig")  
	    public JedisPoolConfig jedisPoolConfig (@Value("${jedis.pool.config.maxTotal}")int maxTotal,  
	                                @Value("${jedis.pool.config.maxIdle}")int maxIdle,  
	                                @Value("${jedis.pool.config.maxWaitMillis}")int maxWaitMillis) {  
	        JedisPoolConfig poolConfig = new JedisPoolConfig();  
	        poolConfig.setMaxTotal(maxTotal);  
	        poolConfig.setMaxIdle(maxIdle);  
	        poolConfig.setMaxWaitMillis(maxWaitMillis);  
	        return poolConfig;  
	    } 
	    
	    @Bean(name= "jedisShardInfo")
	    public JedisShardInfo jedisShardInfoConfig(
	    		@Value("${jedis.pool.config.host}")String host,  
                @Value("${jedis.pool.config.port}")int port,  
                @Value("${jedis.pool.config.password}")String password){
	    	JedisShardInfo jedisConfig = new JedisShardInfo(host,port);
	    	jedisConfig.setPassword(password);
			return jedisConfig;
	    }

	    
}
