package com.cusc.rbac.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
/**
 * 日志记录的开关
 * 一期采用aop的方式写入日志
 * 后期考虑异步的方式写入
 * @author 024-win7-024-DT24
 *
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LogsRecord {

}
