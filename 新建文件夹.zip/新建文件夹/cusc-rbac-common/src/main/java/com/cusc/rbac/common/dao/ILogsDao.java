package com.cusc.rbac.common.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.cusc.rbac.common.vo.LogsVO;

@Mapper
public interface ILogsDao {
	
	public void addLogs(@Param("logsVO")  LogsVO logsVO);

}
