package com.cusc.rbac.common.aop;

import java.lang.annotation.Annotation;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.cusc.rbac.common.annotation.Cacheable;
import com.cusc.rbac.common.annotation.RedisKey;
import com.cusc.rbac.common.annotation.Cacheable.KeyMode;
import com.cusc.rbac.common.services.IRedisService;
import com.cusc.rbac.common.vo.ResponseVO;

/**
 * redis缓存策略
 * 
 * @author 024-win7-024-DT24
 *
 */

@Aspect
@Component
@Order(3)
public class CacheableAop {

	@Autowired
	private IRedisService redisService;

	@Around("@annotation(cache)")
	public Object cached(ProceedingJoinPoint pjp, Cacheable cache) throws Throwable {
		String key = getCacheKey(pjp, cache);
		Object values = redisService.get(key, ResponseVO.class);
		ResponseVO<?> rs = (ResponseVO<?>) values;
		if (rs != null && rs.getData().size() != 0) {
			return values;
		}
		values = pjp.proceed();
		ResponseVO<?> rss = (ResponseVO<?>) values;
		if (rss != null && rss.getData().size() != 0) {
			redisService.set(key, values, cache.expire());
		}
		return values;
	}

	private String getCacheKey(ProceedingJoinPoint pjp, Cacheable cache) {
		StringBuilder buf = new StringBuilder();
		buf.append(cache.key());
		Object[] args = pjp.getArgs();
		if (cache.KeyMode() == KeyMode.DEFAULT) {
			Annotation[][] pas = ((MethodSignature) pjp.getSignature()).getMethod().getParameterAnnotations();
			for (int i = 0; i < pas.length; i++) {
				for (Annotation an : pas[i]) {
					if (an instanceof RedisKey) {
						buf.append(".").append(args[i].toString());
						break;
					}
				}
			}
		} else if (cache.KeyMode() == KeyMode.BASIC) {
			for (Object arg : args) {
				if (arg instanceof String) {
					buf.append(".").append(arg);
				} else if (arg instanceof Integer || arg instanceof Long || arg instanceof Short) {
					buf.append(".").append(arg.toString());
				} else if (arg instanceof Boolean) {
					buf.append(".").append(arg.toString());
				}
			}
		} else if (cache.KeyMode() == KeyMode.ALL) {
			for (Object arg : args) {
				buf.append(".").append(arg.toString());
			}
		}
		return buf.toString();
	}

}
