package com.cusc.rbac.common.aop;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cusc.rbac.common.annotation.LogsRecord;
import com.cusc.rbac.common.services.IIogsService;
import com.cusc.rbac.common.util.IPutil;
import com.cusc.rbac.common.vo.LogsVO;

@Aspect
@Component
@Order(2)
public class LogsControllerAop {
	
	@Autowired
    private IIogsService logsService; 
	
	
	@Pointcut("execution(* com.cusc.rbac.api.services..*.*(..))")
	 public void controllerMethodPointcut(){}; 
	 
	 @After("controllerMethodPointcut()")
	 public Object Interceptor(JoinPoint point) throws ParseException{
		 Object result = true;
		 MethodSignature signature = (MethodSignature) point.getSignature();  
	     Method method = signature.getMethod(); //获取被拦截的方法 
	     LogsRecord logsRecord = method.getAnnotation(LogsRecord.class);
	     RequestAttributes ra = RequestContextHolder.getRequestAttributes();
         ServletRequestAttributes sra = (ServletRequestAttributes) ra;
         HttpServletRequest request   = sra.getRequest();
	     if(logsRecord != null){
	    	 String UserId     =  request.getParameter("Token")!=null?request.getParameter("Token"):request.getHeader("Token");
	    	 String SystemCode =  request.getHeader("SystemCode");
		     String CurTime    =  request.getHeader("CurTime")!=null?request.getHeader("CurTime"):request.getParameter("CurTime");
		     String OperationDesc = request.getParameter("OperationDesc");
		     LogsVO logsVO = new LogsVO();
		     SimpleDateFormat format =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		     String d = format.format(Long.parseLong(CurTime)); 
		     logsVO.setUserId(Long.parseLong(UserId));
		     logsVO.setSystemCode(SystemCode);
		     logsVO.setCreatDate(format.parse(d));
		     logsVO.setLogContent(OperationDesc);
		     logsVO.setIp(IPutil.getRemoteAddrIp(request));
		     logsService.addLogs(logsVO);
	     }
		 return result;
	 }

}
