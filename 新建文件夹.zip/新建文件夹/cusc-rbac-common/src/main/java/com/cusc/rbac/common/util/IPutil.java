package com.cusc.rbac.common.util;

import javax.servlet.http.HttpServletRequest;
/**
 * 通过requist获取用户IP
 * 消除反向代理获取真实IP
 * @author 024-win7-024-DT24
 *
 */
public class IPutil {
	
	private static final String EMPTY_REGEX = "[\\s\\u00a0\\u2007\\u202f\\u0009-u000d\\u001c-\\u001f]+";
	
	public static String getRemoteAddrIp(HttpServletRequest request){
		String ip = request.getHeader("X-Forwarded-For");
		if(isNotEmpty(ip) && !"unKnown".equalsIgnoreCase(ip)){
			int index = ip.indexOf(",");
			if(index != -1){
				return ip.substring(0, index);
			}else{
				return ip;
			}
		}
		ip = request.getHeader("X-Real-IP");
		if(isNotEmpty(ip) && !"unKnown".equalsIgnoreCase(ip)){
			return ip;
		}
		return request.getRemoteAddr();
	 }
	 
	 public static Boolean isEmpty(String input){
		 return input == null || input.equals("") || input.matches(EMPTY_REGEX);
	 }
	 
	 public static Boolean isNotEmpty(String input){
		 return !isEmpty(input);
	 }

}
