package com.cusc.rbac.common.vo;

import java.io.Serializable;
/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class LogsVO extends BaseVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7272384356980784230L;
	
	private Long userId;
	
	private String ip;
	
	private String logContent;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getLogContent() {
		return logContent;
	}

	public void setLogContent(String logContent) {
		this.logContent = logContent;
	}
	
}
