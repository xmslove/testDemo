package com.cusc.rbac.common.services;

public interface IUserCommonInfoService {
	
	/**
	 * 获取用户TOKEN
	 * @param systemCode
	 * @param UserId
	 * @return
	 */
	public String getUserToken(String systemCode,Long UserId,String curTime);

}
