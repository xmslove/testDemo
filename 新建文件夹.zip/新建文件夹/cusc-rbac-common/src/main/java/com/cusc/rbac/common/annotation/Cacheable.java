package com.cusc.rbac.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Cacheable {
	
	public enum KeyMode{
		DEFAULT,
		BASIC,
		ALL;
	}
    
	public String key() default "";
	public KeyMode KeyMode() default KeyMode.DEFAULT;
	public int expire() default 0;
	
}
