package com.cusc.rbac.common.vo;

import java.io.Serializable;
/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class ParamHeaderVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6302156695004727134L;
	
	private String SystemCode; 
	
	private String CurTime;
	
	private String UserToken;

	public String getSystemCode() {
		return SystemCode;
	}

	public void setSystemCode(String systemCode) {
		SystemCode = systemCode;
	}

	public String getCurTime() {
		return CurTime;
	}

	public void setCurTime(String curTime) {
		CurTime = curTime;
	}

	public String getUserToken() {
		return UserToken;
	}

	public void setUserToken(String userToken) {
		UserToken = userToken;
	}
}
