package com.cusc.rbac.common.vo;

import java.io.Serializable;

/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class FunOperationVO extends BaseVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4337467643355184104L;
	
	private Long operationId;
	
	private String operationCode;
	
	private String operationDesc;
	
	private String operationParentCode;

	public Long getOperationId() {
		return operationId;
	}

	public void setOperationId(Long operationId) {
		this.operationId = operationId;
	}

	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	public String getOperationDesc() {
		return operationDesc;
	}

	public void setOperationDesc(String operationDesc) {
		this.operationDesc = operationDesc;
	}

	public String getOperationParentCode() {
		return operationParentCode;
	}

	public void setOperationParentCode(String operationParentCode) {
		this.operationParentCode = operationParentCode;
	}
}
