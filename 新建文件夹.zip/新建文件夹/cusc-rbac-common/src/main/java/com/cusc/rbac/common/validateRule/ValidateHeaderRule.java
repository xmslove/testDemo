package com.cusc.rbac.common.validateRule;

import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.cusc.rbac.common.services.IRedisService;
import com.cusc.rbac.common.services.IUserCommonInfoService;
import com.cusc.rbac.common.vo.ResponseCode;
import com.cusc.rbac.common.vo.ResponseVO;

@Component
public class ValidateHeaderRule {
	
	@Autowired
	private IRedisService redisService;
	
	@Autowired
	private IUserCommonInfoService userCommonInfoService;
	
	public  <T> JSONObject rule(String SystemCode, String CurTime,String UserToken,String UserId) throws Exception{
		ResponseVO<T>  result = new  ResponseVO<T>();
		/*********************头部非空验证**********************/
		if( SystemCode ==null || SystemCode.equals("") ){
			result.setCode("RBAC1001");
			result.setMsg(ResponseCode.getErrorCode("RBAC1001"));
			return (JSONObject) JSONObject.toJSON(result);
		}
		if( CurTime ==null || CurTime.equals("") ){
			result.setCode("RBAC1002");
			result.setMsg(ResponseCode.getErrorCode("RBAC1002"));
			return (JSONObject) JSONObject.toJSON(result);
		}
		if( UserToken ==null || UserToken.equals("") ){
			result.setCode("RBAC1003");
			result.setMsg(ResponseCode.getErrorCode("RBAC1003"));
			return (JSONObject) JSONObject.toJSON(result);
		}
		if( UserId ==null || UserId.equals("") ){
			result.setCode("RBAC1004");
			result.setMsg(ResponseCode.getErrorCode("RBAC1004"));
			return (JSONObject) JSONObject.toJSON(result);
		}
		/*********************时间戳格式验证**********************/
		if(CurTime.length()!=13){
			result.setCode("RBAC1005");
			result.setMsg(ResponseCode.getErrorCode("RBAC1005"));
			return (JSONObject) JSONObject.toJSON(result);
		};
		SimpleDateFormat format =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
	    
	    try {
	    	String d = format.format(CurTime);
			format.parse(d);
		} catch (Exception e) {
			result.setCode("RBAC1005");
			result.setMsg(ResponseCode.getErrorCode("RBAC1005"));
			return (JSONObject) JSONObject.toJSON(result);
		}
	    /*********************用户token验证**********************/
	    String ut = redisService.getKey(UserId);//缓存中获取用户token
	    if(ut == null && "".equals(ut)){
    		//数据库中获取用户密码加密后做token验证
    		String token = userCommonInfoService.getUserToken(SystemCode, Long.parseLong(UserId), CurTime);
    		if(!token.equals(UserToken)){
    			result.setCode("RBAC1006");
    			result.setMsg(ResponseCode.getErrorCode("RBAC1006"));
    			return (JSONObject) JSONObject.toJSON(result);
    		}
    		redisService.setex(UserId, token, 5000);
	    }else if(!ut.equals(UserToken)){
	    	//数据库中获取用户密码加密后做token验证
    		String token = userCommonInfoService.getUserToken(SystemCode, Long.parseLong(UserId), CurTime);
    		if(!token.equals(UserToken)){
    			result.setCode("RBAC1006");
    			result.setMsg(ResponseCode.getErrorCode("RBAC1006"));
    			return (JSONObject) JSONObject.toJSON(result);
    		}
    		redisService.setex(UserId, token, 5000);
	    	}
		return (JSONObject) JSONObject.toJSON(result);
		
	} 

}
