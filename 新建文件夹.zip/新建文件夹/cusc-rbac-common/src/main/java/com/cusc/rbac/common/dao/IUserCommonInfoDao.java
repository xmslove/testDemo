package com.cusc.rbac.common.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface IUserCommonInfoDao {

	String getUserPwd(@Param("systemCode") String systemCode, @Param("userId") Long userId);

}
