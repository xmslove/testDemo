package com.cusc.rbac.starter.vo;

import java.io.Serializable;
/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class PermissionVO extends FunOperationVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3286308169768508314L;
	
	private Long permissionId;
	
	private String permissionType;

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public String getPermissionType() {
		return permissionType;
	}

	public void setPermissionType(String permissionType) {
		this.permissionType = permissionType;
	}
}
