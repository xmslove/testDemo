package com.cusc.rbac.starter.exception;

public class AuthException extends RuntimeException {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1510402355659529249L;

	public AuthException(){
		super();
	}
	
}
