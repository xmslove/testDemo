package com.cusc.rbac.starter.vo;

public enum  ResponseCode {
	
	ERROR1001("RBAC2001","没有权限，请联系管理员");
	
	private String code;
	private String msg;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	private ResponseCode(String code,String msg){
		this.code = code;
		this.msg = msg;
	}
	
	public static String getErrorCode(ResponseCode rc){
		return rc.getCode();
	}
	
	public static String getErrorMsg(ResponseCode rc){
		return rc.getMsg();
	}
}
