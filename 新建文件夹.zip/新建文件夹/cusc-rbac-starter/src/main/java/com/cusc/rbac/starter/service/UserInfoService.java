	package com.cusc.rbac.starter.service;
	
	import com.cusc.rbac.starter.api.UserInfoAPI;
import com.cusc.rbac.starter.vo.GroupVO;
import com.cusc.rbac.starter.vo.ResponseVO;
import com.cusc.rbac.starter.vo.RoleVO;
import com.cusc.rbac.starter.vo.UserInfoVO;
	
	public class UserInfoService {
	
	private String systemCode;
	
	private String apiHost;
	
	private String apiPort;
	
	public UserInfoService(String systemCode, String apiHost,String apiPort) {
	this.systemCode = systemCode;
	this.apiHost = apiHost;
	this.apiPort = apiPort;
	this.API_URL = apiHost + ":" + apiPort;
	this.USER_LOGIN = "http://" + API_URL + "/userInfo/login";
	this.USER_SERVICE_LOGIN = "http://"+API_URL+"/userInfo/serviceLogin";
	this.GET_USER_ROLE = "http://"+API_URL+"/userInfo/getUserRole";
	this.GET_USER_GROUP = "http://"+API_URL+"/userInfo/getUserGroup";
	}
	
	public String getSystemCode() {
	return systemCode;
	}
	
	public void setSystemCode(String systemCode) {
	this.systemCode = systemCode;
	}
	
	public String getApiHost() {
	return apiHost;
	}
	
	public void setApiHost(String apiHost) {
	this.apiHost = apiHost;
	}
	
	public String getApiPort() {
	return apiPort;
	}
	
	public void setApiPort(String apiPort) {
	this.apiPort = apiPort;
	}
	
	private String API_URL;
	
	/**
	* 用户登录
	*/
	private String USER_LOGIN;
	/**
	* service登录
	*/
	private String USER_SERVICE_LOGIN;
	/**
	* 获取用户角色信息地址
	*/
	private String GET_USER_ROLE;
	/**
	* 获取用户组信息地址
	*/
	private String GET_USER_GROUP;
	
	/**
	* 获取用户信息
	* 
	* @param UserId
	* @return
	*/
	public ResponseVO<UserInfoVO> userLogin(String UserName, String UserPassword, String UserMobileNo) {
	return UserInfoAPI.userLogin(systemCode,USER_LOGIN, UserName, UserPassword, UserMobileNo);
	};
	
	/**
	* service 登录
	* 
	* @param UserName
	* @param UserPassword
	* @return
	*/
	public ResponseVO<UserInfoVO> userServiceLogin(String UserName, String UserPassword) {
	return UserInfoAPI.userServiceLogin(systemCode,USER_SERVICE_LOGIN, UserName, UserPassword);
	};
	
	/**
	* 获取用户角色信息
	* 
	* @param CurTime
	* @param UserToken
	* @param UserId
	* @param OperationDesc
	* @return
	* @throws Exception
	*/
	public ResponseVO<RoleVO> getUserRole(String CurTime, String UserToken, String UserId, String OperationDesc)
	throws Exception {
	return UserInfoAPI.getUserRole(systemCode,GET_USER_ROLE,CurTime, UserToken, UserId, OperationDesc);
	}
	
	/**
	* 获取用户组信息
	* 
	* @param CurTime
	* @param UserToken
	* @param UserId
	* @param OperationDesc
	* @return
	* @throws Exception
	*/
	public ResponseVO<GroupVO> getUserGroup(String CurTime, String UserToken, String UserId, String OperationDesc)
	throws Exception {
	return UserInfoAPI.getUserGroup(systemCode,GET_USER_GROUP, CurTime, UserToken, UserId, OperationDesc);
	}
	
	}