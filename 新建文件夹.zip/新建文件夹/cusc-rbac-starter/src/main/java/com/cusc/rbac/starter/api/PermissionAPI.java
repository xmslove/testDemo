package com.cusc.rbac.starter.api;

import java.util.List;

import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cusc.rbac.starter.httpclientUtil.LocalHttpClient;
import com.cusc.rbac.starter.vo.PermissionVO;
import com.cusc.rbac.starter.vo.PrivilegeVO;
import com.cusc.rbac.starter.vo.ResponseVO;


public class PermissionAPI { 
	
	/**
	 * 获取权限资源
	 * @param SystemCode
	 * @param CurTime
	 * @param UserToken
	 * @param UserId
	 * @param OperationDesc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static ResponseVO<PermissionVO> getResource(String SystemCode,String url,String CurTime, String UserToken, String UserId, String OperationDesc){
		HttpUriRequest httpUriRequest = RequestBuilder.post()
				.setUri(url)
				.addHeader("SystemCode", SystemCode)
				.addHeader("CurTime", CurTime)
				.addHeader("UserToken", UserToken)
				.addParameter("UserId", UserId)
				.addParameter("OperationDesc", OperationDesc)
				.build();
		return LocalHttpClient.executeJsonResult(httpUriRequest,ResponseVO.class);
	};
    
	
	/**
	 * 获取权限资源（集成方式）
	 * @param SystemCode
	 * @param CurTime
	 * @param UserToken
	 * @param UserId
	 * @param OperationDesc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> ResponseVO<T> getResourceByJar(String SystemCode,String url,String CurTime,String Token, String OperationDesc){
		HttpUriRequest httpUriRequest = RequestBuilder.post()
				.setUri(url)
				.addHeader("SystemCode", SystemCode)
				.addParameter("CurTime", CurTime)
				.addHeader("Token", Token)
				.addParameter("OperationDesc", OperationDesc)
				.build();
		return LocalHttpClient.executeJsonResult(httpUriRequest,ResponseVO.class);
	}


    /**权限同步到RBAC
     * @param <T>
     * @param ps
     */
	@SuppressWarnings("unchecked")
	public static <T> ResponseVO<T> privilegeSynchronization(List<PrivilegeVO> ps,String url) {
		JSONArray json = new JSONArray();
		for (PrivilegeVO vo : ps) {
			 JSONObject jo = new JSONObject();
			 jo.put("operationCode",vo.getOperationCode());
			 jo.put("operationDesc",vo.getOperationDesc());
			 jo.put("operationType",vo.getOperationType());
			 jo.put("systemCode",vo.getSystemCode());
			 jo.put("parentCode",vo.getParentCode());
			 json.add(jo);
		}
		HttpUriRequest httpUriRequest = RequestBuilder.post()
		.setUri(url)
		.addParameter("Privileges", json.toString())
		.build();
        return LocalHttpClient.executeJsonResult(httpUriRequest,ResponseVO.class);
	};
}
