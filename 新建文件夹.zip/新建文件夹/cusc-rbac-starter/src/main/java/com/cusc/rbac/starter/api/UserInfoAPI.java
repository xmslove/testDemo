package com.cusc.rbac.starter.api;

import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;

import com.cusc.rbac.starter.httpclientUtil.LocalHttpClient;
import com.cusc.rbac.starter.vo.GroupVO;
import com.cusc.rbac.starter.vo.ResponseVO;
import com.cusc.rbac.starter.vo.RoleVO;
import com.cusc.rbac.starter.vo.UserInfoVO;

public class UserInfoAPI {
	
	@SuppressWarnings("unchecked")
	public static ResponseVO<UserInfoVO> userLogin(String SystemCode,String url,String UserName,String UserPassword,String UserMobileNo){
		HttpUriRequest httpUriRequest = RequestBuilder.post()
				.setUri(url)
				.addParameter("SystemCode", SystemCode)
				.addHeader("UserName", UserName)
				.addHeader("UserPassword", UserPassword)
				.addHeader("UserMobileNo", UserMobileNo)
				.addHeader("CurTime",String.valueOf(System.currentTimeMillis()))
				.build();
		return LocalHttpClient.executeJsonResult(httpUriRequest,ResponseVO.class);
	}
	
	@SuppressWarnings("unchecked")
	public static ResponseVO<UserInfoVO> userServiceLogin(String SystemCode,String url, String UserName,String UserPassword){
		HttpUriRequest httpUriRequest = RequestBuilder.post()
				.setUri(url)
				.addParameter("SystemCode", SystemCode)
				.addHeader("UserName", UserName)
				.addHeader("UserPassword", UserPassword)
				.addHeader("CurTime",String.valueOf(System.currentTimeMillis()))
				.build();
		return LocalHttpClient.executeJsonResult(httpUriRequest,ResponseVO.class);
	}
	
	/**
	 * 获取角色信息
	 * @param SystemCode
	 * @param CurTime
	 * @param UserToken
	 * @param UserId
	 * @param OperationDesc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static ResponseVO<RoleVO> getUserRole(String SystemCode,String CurTime,String url, String UserToken, String UserId, String OperationDesc){
		HttpUriRequest httpUriRequest = RequestBuilder.get()
				.setUri(url)
				.addHeader("SystemCode", SystemCode)
				.addHeader("CurTime", CurTime)
				.addHeader("UserToken", UserToken)
				.addParameter("UserId", UserId)
				.addParameter("OperationDesc", OperationDesc)
				.build();
		return LocalHttpClient.executeJsonResult(httpUriRequest,ResponseVO.class);
	}
   
	/**
	 * 获取用户组信息
	 * @param systemCode
	 * @param curTime
	 * @param userToken
	 * @param userId
	 * @param operationDesc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static ResponseVO<GroupVO> getUserGroup(String systemCode,String url, String curTime, String userToken, String userId,
			String operationDesc) {
		HttpUriRequest httpUriRequest = RequestBuilder.get()
		.setUri(url)
		.addHeader("SystemCode", systemCode)
		.addHeader("CurTime", curTime)
		.addHeader("UserToken", userToken)
		.addParameter("UserId", userId)
		.addParameter("OperationDesc", operationDesc)
		.build();
        return LocalHttpClient.executeJsonResult(httpUriRequest,ResponseVO.class);
	};

}
