package com.cusc.rbac.starter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cusc.rbac.starter.service.UserInfoService;
import com.cusc.rbac.starter.vo.PermissionProperteis;

@Configuration                                                                                                                              
@EnableConfigurationProperties(value = PermissionProperteis.class)                                                                        
@ConditionalOnClass(UserInfoService.class)                                                                                                     
@ConditionalOnProperty(prefix = "rbac.permission", value = "enable", matchIfMissing = true)
@ConditionalOnExpression("${rbac.userinfo.client.enabled:false}")
public class UserInfoAutoConfiguration {
	
	@Autowired                                                                                                                              
    private PermissionProperteis permissionProperteis;
	
	@Bean                                                                                                                                   
    @ConditionalOnMissingBean(UserInfoService.class)                                                                                           
    public UserInfoService userInfoService() {
		return  new UserInfoService(permissionProperteis.getSystemCode(),permissionProperteis.getApiHost(),permissionProperteis.getApiPort());
		}

}
