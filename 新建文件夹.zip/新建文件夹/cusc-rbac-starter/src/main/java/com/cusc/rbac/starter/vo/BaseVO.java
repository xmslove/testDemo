package com.cusc.rbac.starter.vo;

import java.io.Serializable;
import java.util.Date;
/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class BaseVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4966309981646226817L;
	
	private Date creatDate;
	
	private Date updateDate;
	
	private String systemCode;

	public Date getCreatDate() {
		return creatDate;
	}

	public void setCreatDate(Date creatDate) {
		this.creatDate = creatDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
	
	

}
