package com.cusc.rbac.starter;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.cusc.rbac.starter.annotation.OperationSource;
import com.cusc.rbac.starter.api.PermissionAPI;
import com.cusc.rbac.starter.vo.PermissionProperteis;
import com.cusc.rbac.starter.vo.PrivilegeVO;

@Configuration
@EnableConfigurationProperties(value = PermissionProperteis.class)
@ConditionalOnProperty(prefix = "rbac.permission", value = "enable", matchIfMissing = true)
public class PrivilegeSyncConfiguration implements CommandLineRunner {

	@Autowired
	private PermissionProperteis permissionProperteis;
	
	private static final String INDEX_ = "@#@";

	@Override
	@SuppressWarnings("rawtypes")
	public void run(String... args) throws Exception {
		String packageName = permissionProperteis.getPackageName();
		List<Class> classes = null;
		Set<String> ppp = new HashSet<String>();
		try {
			classes = getClassesByPackageName(packageName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		for (Class clas : classes) {
			Method[] methods = clas.getMethods();
			for (Method method : methods) {
				OperationSource operationSource = method.getAnnotation(OperationSource.class);
				if (operationSource != null){
					ppp.add(operationSource.code() + INDEX_ + operationSource.operation() + INDEX_
							+ operationSource.operationType() + INDEX_ + operationSource.parentCode());
				}
			}
		}
		if(ppp.size()!=0){
			privilegeSynchronization(ppp);
		}
	}

	/**
	 * 吧权限资源同步到RBAC
	 * 
	 * @param pl
	 * @throws Exception
	 */
	private void privilegeSynchronization(Set<String> pl) throws Exception {
		List<PrivilegeVO> ps = new ArrayList<PrivilegeVO>();
		for (String string : pl) {
			PrivilegeVO vo = new PrivilegeVO();
			List<String> result = Arrays.asList(string.split(INDEX_));
			vo.setOperationCode(result.get(0));
			vo.setOperationDesc(result.get(1));
			vo.setOperationType(result.get(2));
			vo.setParentCode(result.get(3));
			vo.setSystemCode(permissionProperteis.getSystemCode());
			ps.add(vo);
		}
		String url = "http://"+permissionProperteis.getApiHost()+":"+permissionProperteis.getApiPort()+"/permission/privilegeSyncHronization";
		PermissionAPI.privilegeSynchronization(ps,url);
	}

	@SuppressWarnings("rawtypes")
	private static List<Class> getClassesByPackageName(String packageName) throws IOException, ClassNotFoundException {

		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		String path = packageName.replace('.', '/');
		Enumeration<URL> resources = classLoader.getResources(path);
		List<File> dirs = new ArrayList<File>();
		while (resources.hasMoreElements()) {
			URL resource = resources.nextElement();
			dirs.add(new File(resource.getFile()));
		}
		ArrayList<Class> classes = new ArrayList<Class>();
		for (File directory : dirs) {
			classes.addAll(findClasses(directory, packageName));
		}
		return classes;
	}

	@SuppressWarnings("rawtypes")
	private static List<Class> findClasses(File directory, String packageName) throws ClassNotFoundException {
		List<Class> classes = new ArrayList<Class>();
		if (!directory.exists()) {
			return classes;
		}
		File[] files = directory.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				assert !file.getName().contains(".");
				classes.addAll(findClasses(file, packageName + '.' + file.getName()));
			} else if (file.getName().endsWith(".class")) {
				classes.add(
						Class.forName(packageName + "." + file.getName().substring(0, file.getName().length() - 6)));
			}
		}
		return classes;
	}

}
