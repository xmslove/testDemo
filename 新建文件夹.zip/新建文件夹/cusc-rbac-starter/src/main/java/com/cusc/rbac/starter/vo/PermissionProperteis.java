package com.cusc.rbac.starter.vo;

import org.springframework.boot.context.properties.ConfigurationProperties;
/**
 * application中定义配置的属性
 * @author 024-win7-024-DT24
 *
 */
@ConfigurationProperties(prefix = "rbac.permission") 
public class PermissionProperteis {
	
	/**
	 * rbac.permission.systemCode
	 */
	private String systemCode;
	
	/**
	 * rbac.permission.packageName
	 */
	private String packageName;
	
	private String apiHost;
	
	private String apiPort;
	

	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getApiHost() {
		return apiHost;
	}

	public void setApiHost(String apiHost) {
		this.apiHost = apiHost;
	}

	public String getApiPort() {
		return apiPort;
	}

	public void setApiPort(String apiPort) {
		this.apiPort = apiPort;
	}
	
}
