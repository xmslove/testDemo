package com.cusc.rbac.starter.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import com.cusc.rbac.starter.OperationSourceAutoConfiguration;
/**
 * 用注解的形式引用starter中的AOP
 * @author 024-win7-024-DT24
 *
 */
@Target({ElementType.FIELD,ElementType.METHOD,ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
@Import(OperationSourceAutoConfiguration.class)
public @interface OperationSource {
	
	/**
	 * 权限的CODE
	 * @return
	 */
	String code() default "";
	
	/**
	 * 权限的描述
	 * @return
	 */
	String operation() default "";
	
	/**
	 * 权限的类型
	 * @return
	 */
	String operationType() default "";
	
	/**
	 * 父权限CODE
	 * @return
	 */
	String parentCode() default "";
	
}
