package com.cusc.rbac.starter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cusc.rbac.starter.service.PermissionService;
import com.cusc.rbac.starter.vo.PermissionProperteis;

@Configuration                                                                                                                              
@EnableConfigurationProperties(value = PermissionProperteis.class)                                                                        
@ConditionalOnClass(PermissionService.class)                                                                                                     
@ConditionalOnProperty(prefix = "rbac.permission", value = "enable", matchIfMissing = true)
@ConditionalOnExpression("${rbac.permission.client.enabled:false}")
public class PermissionAutoConfiguration {
	
	@Autowired                                                                                                                              
    private PermissionProperteis permissionProperteis; 
	
	@Bean                                                                                                                                   
    @ConditionalOnMissingBean(PermissionService.class)                                                                                           
    public PermissionService permissionService() {
		return  new PermissionService(permissionProperteis.getSystemCode(),permissionProperteis.getApiHost(),permissionProperteis.getApiPort());
		} 

}
