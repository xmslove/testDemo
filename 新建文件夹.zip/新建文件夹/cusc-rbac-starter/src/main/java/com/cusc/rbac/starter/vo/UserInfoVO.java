package com.cusc.rbac.starter.vo;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author 024-win7-024-DT24
 *
 */
public class UserInfoVO  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -186595389853603923L;
	
	
	private Long userId;
	
	private String userName;
	
	private List<RoleVO> roles;
	
	private List<PermissionVO> permissions;
	
	private String token;
	
	private Long expiredTime;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<RoleVO> getRoles() {
		return roles;
	}

	public void setRoles(List<RoleVO> roles) {
		this.roles = roles;
	}

	public List<PermissionVO> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<PermissionVO> permissions) {
		this.permissions = permissions;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Long getExpiredTime() {
		return expiredTime;
	}

	public void setExpiredTime(Long expiredTime) {
		this.expiredTime = expiredTime;
	}
   
}
