package com.cusc.rbac.starter.service;

import com.cusc.rbac.starter.api.PermissionAPI;
import com.cusc.rbac.starter.vo.PermissionVO;
import com.cusc.rbac.starter.vo.ResponseVO;

public class PermissionService{
	
	private String systemCode;

	private String apiHost;
	
	private String apiPort;
	
	private String URL;

	public PermissionService(String systemCode, String apiHost,String apiPort) {
		this.systemCode = systemCode;
		this.apiHost = apiHost;
		this.apiPort = apiPort;
		this.URL = "http://" + apiHost + ":" + apiPort + "/permission/getResource";
	}

	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
	
	public String getApiHost() {
		return apiHost;
	}

	public void setApiHost(String apiHost) {
		this.apiHost = apiHost;
	}

	public String getApiPort() {
		return apiPort;
	}

	public void setApiPort(String apiPort) {
		this.apiPort = apiPort;
	}
	
	
	

	/**
	 * 获取用户权限资源
	 * @param CurTime
	 * @param UserToken
	 * @param UserId
	 * @param OperationDesc
	 * @return
	 * @throws Exception
	 */
	public ResponseVO<PermissionVO> getResource(String CurTime, String UserToken, String UserId, String OperationDesc)
			throws Exception {
		return PermissionAPI.getResource(systemCode,URL, CurTime, UserToken, UserId, OperationDesc);
	}

}