package com.cusc.rbac.starter;

import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSONArray;
import com.cusc.rbac.starter.annotation.OperationSource;
import com.cusc.rbac.starter.api.PermissionAPI;
import com.cusc.rbac.starter.vo.PermissionProperteis;
import com.cusc.rbac.starter.vo.PermissionVO;
import com.cusc.rbac.starter.vo.ResponseVO;
/**
 * 权限验证
 * 需要携带用户ID
 * @author 024-win7-024-DT24
 *
 */
@Aspect
@Order(1)
@Configuration                                                                                                                              
@EnableConfigurationProperties(value = PermissionProperteis.class)                                                                        
@ConditionalOnProperty(prefix = "rbac.permission", value = "enable", matchIfMissing = true)
public class OperationSourceAutoConfiguration {
	
	@Autowired                                                                                                                              
    private PermissionProperteis permissionProperteis;
	
	 @Pointcut("@annotation(com.cusc.rbac.starter.annotation.OperationSource)")
	 public void serviceMethodPointcut(){};
	 
	 
	@Before("serviceMethodPointcut()")
	 public <T> Object interceptor(JoinPoint point) throws Throwable{
		 Object result = true;
		 MethodSignature signature = (MethodSignature) point.getSignature();  
	     Method method = signature.getMethod(); //获取被拦截的方法 
	     OperationSource operationSource = method.getAnnotation(OperationSource.class);
		 RequestAttributes ra = RequestContextHolder.getRequestAttributes();
         ServletRequestAttributes sra = (ServletRequestAttributes) ra;
         HttpServletRequest request = sra.getRequest();
         String token = request.getHeader("token");
         String systemCode = permissionProperteis.getSystemCode();
         String curTime = String.valueOf(System.currentTimeMillis());
         String operation = operationSource.operation();
         String permissionCode = operationSource.code(); 
         String url = "http://"+permissionProperteis.getApiHost()+":"+permissionProperteis.getApiPort()+"/permission/getResourceByJar";
         ResponseVO<T> permissions = PermissionAPI.getResourceByJar(systemCode,url,curTime, token, operation);
         List<PermissionVO>  pl = JSONArray.parseArray(permissions.getData().toString(), PermissionVO.class);
		 if(permissions!=null && permissions.getCode().equals("200")){
			 for (PermissionVO permissionVO : pl) {
				if(permissionVO.getOperationCode().equals(permissionCode)){
					return result;
				}
			}
		 };
		 /*ResponseVO<T>  vo = new  ResponseVO<T>();
		 vo.setCode(ResponseCode.getErrorCode(ResponseCode.ERROR1001));
		 vo.setMsg(ResponseCode.getErrorMsg(ResponseCode.ERROR1001));
		 response.reset();
    	 response.setCharacterEncoding("UTF-8");  
    	 response.setContentType("application/json; charset=utf-8");
    	 PrintWriter out = response.getWriter();
		    out.append(((JSONObject) JSONObject.toJSON(vo)).toString());
		    out.flush();
		    out.close();
		    result = false ;
            return result;*/
		 throw new com.cusc.rbac.starter.exception.AuthException();
		 
    }
}
