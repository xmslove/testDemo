package com.cusc.rbac.api.services;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cusc.rbac.common.vo.GroupVO;
import com.cusc.rbac.common.vo.ResponseVO;
import com.cusc.rbac.common.vo.RoleVO;
import com.cusc.rbac.common.vo.UserInfoVO;
/**
 * 用户信息
 * @author 024-win7-024-DT24
 *
 */
@RequestMapping("/userInfo")
public interface IUserInfoService {
	
	/**
	 * 客户端登录
	 * @param SystemCode
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseVO<UserInfoVO> login(String SystemCode, String UserName,String UserPassword, String UserMobileNo,String CurTime) throws Exception;
	
	
	/**
	 * 接口登录
	 * @param SystemCode
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/serviceLogin", method = RequestMethod.POST)
	public ResponseVO<UserInfoVO> serviceLogin(String SystemCode, String UserName,String UserPassword,String CurTime) throws Exception;
	
	/**
	 * 获取用户角色信息
	 * @param SystemCode
	 * @param CurTime
	 * @param UserToken
	 * @param UserId
	 * @param OperationDesc
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getUserRole", method = RequestMethod.POST)
	public ResponseVO<RoleVO> getUserRole(String SystemCode,String CurTime,String UserToken,String UserId,String OperationDesc)throws Exception;

    /**
     * 获取用户组信息
     * @param SystemCode
     * @param CurTime
     * @param UserToken
     * @param UserId
     * @param OperationDesc
     * @return
     * @throws Exception
     */
	@RequestMapping(value = "/getUserGroup", method = RequestMethod.POST)
	public ResponseVO<GroupVO> getUserGroup(String SystemCode,String CurTime,String UserToken,String UserId,String OperationDesc)throws Exception;
}
