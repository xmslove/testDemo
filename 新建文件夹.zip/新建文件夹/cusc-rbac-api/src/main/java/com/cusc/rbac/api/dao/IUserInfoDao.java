package com.cusc.rbac.api.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.cusc.rbac.common.vo.GroupVO;
import com.cusc.rbac.common.vo.RoleVO;
import com.cusc.rbac.common.vo.UserInfoVO;

@Mapper
public interface IUserInfoDao {

	List<RoleVO> getUserRole(@Param("systemCode") String systemCode,@Param("userId") String userId);

	List<GroupVO> getUserGroup(@Param("systemCode") String systemCode,@Param("userId") String userId);

	UserInfoVO getUserInfo(@Param("systemCode") String systemCode, @Param("userName") String userName, @Param("userPassword") String userPassword,@Param("userMobileNo") String UserMobileNo);

	UserInfoVO getUser(@Param("systemCode") String systemCode, @Param("userName") String userName, @Param("userPassword") String userPassword);

}
