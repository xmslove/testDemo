package com.cusc.rbac.api.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cusc.rbac.api.dao.IUserInfoDao;
import com.cusc.rbac.api.dao.IUserPermissionDao;
import com.cusc.rbac.api.services.IUserInfoService;
import com.cusc.rbac.common.annotation.Cacheable;
import com.cusc.rbac.common.annotation.RedisKey;
import com.cusc.rbac.common.annotation.ValidateHeader;
import com.cusc.rbac.common.services.IRedisService;
import com.cusc.rbac.common.vo.GroupVO;
import com.cusc.rbac.common.vo.PermissionVO;
import com.cusc.rbac.common.vo.RedisKeyConstant;
import com.cusc.rbac.common.vo.ResponseVO;
import com.cusc.rbac.common.vo.RoleVO;
import com.cusc.rbac.common.vo.UserInfoVO;

/**
 * 
 * @author 024-win7-024-DT24
 *
 */
@RestController
public class UserInfoServiceImpl implements IUserInfoService{
	
	@Autowired
	private IUserInfoDao userInfoDao;
	@Autowired
	private IUserPermissionDao userPermissionDao;
	@Autowired
	private IRedisService  redisService;
	
	private static final int EXPIRED_TIME = 1000*60*60*24;
	
	
	@Override
	public ResponseVO<UserInfoVO> login(
			@RequestParam(value="SystemCode",required = false) String SystemCode,
			@RequestHeader(value="UserName",required = false) String UserName,
			@RequestHeader(value="UserPassword",required = false)   String UserPassword,
			@RequestHeader(value="UserMobileNo",required = false) String UserMobileNo,
			@RequestHeader(value="CurTime",required = false) String CurTime
			) throws Exception {
		ResponseVO<UserInfoVO> result = new ResponseVO<UserInfoVO>();
		UserInfoVO userInfo = new UserInfoVO();
		userInfo = userInfoDao.getUserInfo(SystemCode,UserName,UserPassword,UserMobileNo);
		if(userInfo==null){
			return null; 
		};
		List<RoleVO> roles = userInfoDao.getUserRole(SystemCode,String.valueOf(userInfo.getUserId()));
		List<PermissionVO> permissions = userPermissionDao.findUserPermission(SystemCode,String.valueOf(userInfo.getUserId()));
		userInfo.setRoles(roles);
		userInfo.setPermissions(permissions);
		userInfo.setUserName(userInfo.getUserName());
		userInfo.setUserId(userInfo.getUserId());
		String token = UUID.randomUUID().toString(); 
		userInfo.setToken(token);
		userInfo.setExpiredTime(System.currentTimeMillis()+EXPIRED_TIME);
		redisService.setex(token,String.valueOf(userInfo.getUserId()),EXPIRED_TIME);
		List<UserInfoVO> user =  new ArrayList<UserInfoVO>();
		user.add(userInfo);
		result.setData(user);
		return result;
	}

	@Override
	@ValidateHeader
	@Cacheable(expire=5000,key=RedisKeyConstant.USERROLE_KEY)
	public ResponseVO<RoleVO> getUserRole(
			@RequestHeader(value="SystemCode",required = false) @RedisKey       String SystemCode,
			@RequestHeader(value="CurTime",required = false)      	  			String CurTime,
			@RequestHeader(value="UserToken",required = false)   	 			String UserToken,
			@RequestParam(value="UserId",required = false)      @RedisKey  		String UserId,
			@RequestParam(value="OperationDesc",required = false)     			String OperationDesc) throws Exception {
		
		ResponseVO<RoleVO> rs = new ResponseVO<RoleVO>();
		List<RoleVO> userRole = userInfoDao.getUserRole(SystemCode,UserId);
		rs.setData(userRole);
		return rs;
	}

	@Override
	@ValidateHeader
	@Cacheable(expire=5000,key=RedisKeyConstant.USERGROUP_KEY)
	public ResponseVO<GroupVO> getUserGroup(
			@RequestHeader(value="SystemCode",required = false) @RedisKey       String SystemCode,
			@RequestHeader(value="CurTime",required = false)      	  			String CurTime,
			@RequestHeader(value="UserToken",required = false)   	 			String UserToken,
			@RequestParam(value="UserId",required = false)      @RedisKey  		String UserId,
			@RequestParam(value="OperationDesc",required = false)     			String OperationDesc) throws Exception {

		ResponseVO<GroupVO> rs = new ResponseVO<GroupVO>();
		List<GroupVO> userGroup = userInfoDao.getUserGroup(SystemCode,UserId);
		rs.setData(userGroup);
		return rs;
	}

	@Override
	public ResponseVO<UserInfoVO> serviceLogin(
			@RequestParam(value="SystemCode",required = false) String SystemCode,
			@RequestHeader(value="UserName",required = false) String UserName,
			@RequestHeader(value="UserPassword",required = false) String UserPassword,
			@RequestHeader(value="CurTime",required = false) String CurTime) throws Exception {
		ResponseVO<UserInfoVO> result = new ResponseVO<UserInfoVO>();
		UserInfoVO userInfo  = userInfoDao.getUser(SystemCode,UserName,UserPassword);
		if(userInfo==null){
			return null; 
		}
		String token = UUID.randomUUID().toString(); 
		userInfo.setToken(token);
		userInfo.setExpiredTime(System.currentTimeMillis()+EXPIRED_TIME);
		redisService.setex(token,String.valueOf(userInfo.getUserId()),EXPIRED_TIME);
		List<UserInfoVO> user =  new ArrayList<UserInfoVO>();
		user.add(userInfo);
		result.setData(user);
		return result;
	}

}
