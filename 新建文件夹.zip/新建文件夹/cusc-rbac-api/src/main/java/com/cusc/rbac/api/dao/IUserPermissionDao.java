package com.cusc.rbac.api.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.cusc.rbac.common.vo.FunOperationVO;
import com.cusc.rbac.common.vo.PermissionVO;

@Mapper
public interface IUserPermissionDao {

	List<PermissionVO> findUserPermission(@Param("systemCode") String systemCode,@Param("userId") String userId);

	void deleteUserRolePermissions(@Param("systemCode") String systemCode);
	
	void deletePermissions(@Param("systemCode") String systemCode);

	void deleteOperations(@Param("systemCode") String systemCode);

	void deletePermissionOperations(@Param("systemCode") String systemCode);

	Long  addOperation(@Param("funOperationVO") FunOperationVO funOperationVO);

	Long  addPermission(@Param("permissionVO") PermissionVO permissionVO);

	void addPermissionOperation(@Param("operationId") Long operationId,@Param("permissionId") Long permissionId,@Param("systemCode") String systemCode);

	


}
