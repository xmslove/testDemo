package com.cusc.rbac.api.services;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cusc.rbac.common.vo.PermissionVO;
import com.cusc.rbac.common.vo.ResponseVO;

@RequestMapping("/permission")
public interface IUserPermissionService<T> {
	
	/**
	 * 非jar包集成方式用户请求权限资源
	 * @param SystemCode
	 * @param CurTime
	 * @param UserToken
	 * @param UserId
	 * @param OperationDesc
	 * @return
	 */
	@RequestMapping(value = "/getResource", method = RequestMethod.POST)
	public ResponseVO<PermissionVO> getResource(String SystemCode,String CurTime,String UserToken,String UserId,String OperationDesc)throws Exception;  
    
	
	/**
	 * jar包集成方式用户请求权限资源
	 * @param SystemCode
	 * @param CurTime
	 * @param UserId
	 * @param OperationDesc
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getResourceByJar", method = RequestMethod.POST)
	public ResponseVO<PermissionVO> getResourceByJar(String SystemCode,String CurTime,String Token,String OperationDesc)throws Exception;

    /**
     * 权限同步
     * @param Privileges
     * @return
     * @throws Exception
     */
	@RequestMapping(value = "/privilegeSyncHronization", method = RequestMethod.POST)
	ResponseVO<T> privilegeSyncHronization(String Privileges) throws Exception;
}
