package com.cusc.rbac.api.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.cusc.rbac.api.dao.IUserPermissionDao;
import com.cusc.rbac.api.services.IUserPermissionService;
import com.cusc.rbac.common.annotation.Cacheable;
import com.cusc.rbac.common.annotation.RedisKey;
import com.cusc.rbac.common.annotation.ValidateHeader;
import com.cusc.rbac.common.services.IRedisService;
import com.cusc.rbac.common.vo.FunOperationVO;
import com.cusc.rbac.common.vo.PermissionVO;
import com.cusc.rbac.common.vo.PrivilegeVO;
import com.cusc.rbac.common.vo.RedisKeyConstant;
import com.cusc.rbac.common.vo.ResponseVO;

@RestController
public class UserPermissionServiceImpl<T> implements IUserPermissionService<T>{
	
	@Autowired
	private IUserPermissionDao userPermissionDao;
	@Autowired
	private IRedisService redisService;
	
	@Override
	@ValidateHeader
	@Cacheable(expire=5000,key=RedisKeyConstant.PERMISSION_KEY)
	public ResponseVO<PermissionVO> getResource(
			@RequestHeader(value="SystemCode",required = false) @RedisKey       String SystemCode,
			@RequestHeader(value="CurTime",required = false)      	  			String CurTime,
			@RequestHeader(value="UserToken",required = false)   	 			String UserToken,
			@RequestParam(value="UserId",required = false)      @RedisKey  		String UserId,
			@RequestParam(value="OperationDesc",required = false)     			String OperationDesc) throws Exception{
		
		ResponseVO<PermissionVO> rs = new ResponseVO<PermissionVO>();
		List<PermissionVO> permission = userPermissionDao.findUserPermission(SystemCode,UserId);
		rs.setData(permission);
		return rs;
		
	}

	@Override
	@Cacheable(expire=5000,key=RedisKeyConstant.PERMISSION_KEY)
	public ResponseVO<PermissionVO> getResourceByJar(
			@RequestHeader(value="SystemCode",required = false)                  String SystemCode, 
			@RequestParam(value="CurTime",required = false)                      String CurTime,
			@RequestHeader(value="Token",required = false)      @RedisKey 	     String Token,
			@RequestParam(value="OperationDesc",required = false) 				 String OperationDesc
			) throws Exception {

		ResponseVO<PermissionVO> rs = new ResponseVO<PermissionVO>();
		String userId = redisService.getKey(Token);
		if(userId==null){
			return null;
		}
		List<PermissionVO> permission = userPermissionDao.findUserPermission(SystemCode,userId);
		rs.setData(permission);
		return rs;
	}

	/**
	 * 暂时删除原来的权限同步新的权限
	 * 待优化
	 */
	@Override
	public  ResponseVO<T> privilegeSyncHronization(
			@RequestParam(value="Privileges",required = false) String Privileges
			) throws Exception {
		
		ResponseVO<T> rs = new ResponseVO<T>();
		List<PrivilegeVO> pvs = new ArrayList<PrivilegeVO>();
		pvs = JSONArray.parseArray(Privileges, PrivilegeVO.class);
		if(pvs!=null && pvs.size()!=0){
		  String systemCode = pvs.get(0).getSystemCode();
		  userPermissionDao.deleteUserRolePermissions(systemCode);
		  userPermissionDao.deletePermissions(systemCode);
		  userPermissionDao.deleteOperations(systemCode);
		  userPermissionDao.deletePermissionOperations(systemCode);
		  for (PrivilegeVO privilegeVO : pvs) {
			  FunOperationVO fv = new FunOperationVO();
			  fv.setOperationCode(privilegeVO.getOperationCode());
			  fv.setOperationDesc(privilegeVO.getOperationDesc());
			  fv.setOperationParentCode(privilegeVO.getParentCode());
			  fv.setSystemCode(privilegeVO.getSystemCode());
			  userPermissionDao.addOperation(fv);
			  PermissionVO   pp  =  new  PermissionVO();
			  pp.setSystemCode(privilegeVO.getSystemCode());
			  pp.setPermissionType(privilegeVO.getOperationType());
			  userPermissionDao.addPermission(pp);
			  userPermissionDao.addPermissionOperation(fv.getOperationId(),pp.getPermissionId(),privilegeVO.getSystemCode());
		 }
		}
		return rs;
	}

}
