package com.cusc.rbac.api;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@ComponentScan(basePackages = "com.cusc.rbac")
@MapperScan({"com.cusc.rbac.api.dao","com.cusc.rbac.common.dao"})
@EnableAsync
public class CuscRbacApiApplicatiion {
	
	public static void main(String[] args) {
		SpringApplication.run(CuscRbacApiApplicatiion.class, args);
	}
	

}
